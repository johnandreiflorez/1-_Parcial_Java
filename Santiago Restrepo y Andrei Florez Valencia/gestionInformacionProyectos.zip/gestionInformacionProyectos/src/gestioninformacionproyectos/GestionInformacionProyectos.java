package gestioninformacionproyectos;

import gestioninformacionproyectos.Configuration.SessionData;
import gestioninformacionproyectos.View.Login;

/**
 *
 * @author srestrepo
 */
public class GestionInformacionProyectos {

    public static void main(String[] args) {
        Login objLogin = new Login();
        objLogin.setVisible(true);
    }
    
}
